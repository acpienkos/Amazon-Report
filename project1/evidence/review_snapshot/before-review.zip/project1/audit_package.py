"""Final mechanical package audit; never represents pending human work as done."""
import sys
from pathlib import Path
HERE=Path(__file__).resolve().parent;sys.path.insert(0,str(HERE));sys.dont_write_bytecode=True
import json,csv,hashlib,subprocess
from datetime import datetime,timezone
from pypdf import PdfReader
import analysis
def main():
    checks=[]
    def check(name,condition):checks.append(dict(check=name,passed=bool(condition)))
    d=json.loads((HERE/'outputs/valuation.json').read_text())
    v=json.loads((HERE/'evidence/validation_summary.json').read_text())
    app=json.loads((HERE/'evidence/app_test.json').read_text())
    cold=json.loads((HERE/'evidence/cold_run.json').read_text())
    check('Historical preservation',analysis.preserve_check()>=64)
    required=['app.py','model.py','config.py','analysis.py','README.md','requirements.txt','requirements-lock.txt',
      'data/historical_reported.csv','data/normalization.csv','data/assumptions.csv','data/source_register.csv',
      'outputs/valuation.json','outputs/visible_output.json','outputs/valuation-report.md','outputs/statements.csv',
      'outputs/fcff_reconciliation.csv','outputs/enterprise_equity_bridge.csv','outputs/comparables.csv','outputs/scenarios.csv',
      'outputs/sensitivity.csv','docs/research-evolution.pdf','docs/decision-memo.pdf','docs/validation-and-ai-use.pdf',
      'docs/historical/amazon-edition-a.md','docs/historical/lab-03-checkout-draft.md','submission/project-submission-manifest.csv']
    check('Required technical/local draft files exist',all((HERE/p).is_file() for p in required))
    check('Latest automated tests passed',v['failed']==0 and v['errors']==0 and v['passed']>=49)
    check('All dashboard pages executed',app['passed']==7 and app['failed']==0)
    check('Fresh environment technical cold run',cold['status']=='PASS' and cold['server']['health']=='ok')
    check('Visible JSON matches financial JSON',(HERE/'outputs/valuation.json').read_bytes()==(HERE/'outputs/visible_output.json').read_bytes())
    memo=(HERE/'docs/decision-memo.md').read_text(encoding='utf-8')
    check('Memo agrees with base result',f"${d['base']['valuation']['per_share']:,.2f}" in memo and f"{d['base']['valuation']['wacc']:.2%}" in memo)
    check('Committee memo <=2 pages',len(PdfReader(HERE/'docs/decision-memo.pdf').pages)<=2)
    check('PDF source/content copies identical',all((HERE/f'docs/{n}.pdf').read_bytes()==(HERE/f'submission/{s}.pdf').read_bytes() for n,s in [('research-evolution','Research-Evolution'),('decision-memo','Decision-Memo'),('validation-and-ai-use','Validation-and-AI-Use')]))
    with (HERE/'submission/project-submission-manifest.csv').open(encoding='utf-8',newline='') as f:manifest=list(csv.DictReader(f))
    check('Official 12-row manifest retained',len(manifest)==12 and sum(r['required']=='yes' for r in manifest)==11)
    check('Unrecorded transcripts clearly labeled',all('NOT RECORDED' in (HERE/f'docs/transcript-video-{i}.txt').read_text() for i in [1,2,3]))
    check('Only dated market observations claimed',d['as_of']=='2026-09-10' and d['price']==251.89)
    pending=['Student AI-off Locked Changed-Input Record and actual execution',
      'Personal source/definition verification and review of provisional financial judgments',
      'Actual recordings, corrected transcripts, stable video links and evidence timestamps',
      'Full Brightspace assignment/rubric/access requirements; precise separate early-AI recovery clarification',
      'Human independently observed cold run if required',
      'Final PDF review, permission for commit/push, grader access and personal submission']
    financial=['Seasonal/actual-period stub reconciliation','Exact valuation-date balance and diluted-share bridge',
               'Separate strategic-investment value and related taxes/commitments','Evidence for terminal capital-turnover transition']
    result=dict(audited_at_utc=datetime.now(timezone.utc).isoformat(),checks=checks,
      passed=sum(x['passed'] for x in checks),failed=sum(not x['passed'] for x in checks),
      student_tasks=pending,material_financial_limitations=financial,submission_ready=False,
      conclusion='Technical local draft built and tested; provisional financial results and essential student evidence prevent a claim of submission readiness.')
    (HERE/'evidence/final_audit.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
    text='# Final package audit\n\n'+result['conclusion']+'\n\n'+f"Mechanical checks: {result['passed']} passed, {result['failed']} failed.\n\n"
    text+='\n'.join(('- PASS ' if x['passed'] else '- FAIL ')+x['check'] for x in checks)
    text+='\n\n## Awaiting student action\n\n'+'\n'.join('- '+x for x in pending)
    text+='\n\n## Material financial limitations\n\n'+'\n'.join('- '+x for x in financial)
    text+='\n\nAll new work is local. No commit, push, deployment, Brightspace submission, checkpoint receipt, human prediction or recording is claimed. Original September1 Edition A is preserved; October19 additions remain later developments.\n'
    (HERE/'evidence/final_audit.md').write_text(text,encoding='utf-8')
    print(json.dumps(dict(passed=result['passed'],failed=result['failed'],submission_ready=False)))
    raise SystemExit(0 if result['failed']==0 else 1)
if __name__=='__main__':main()
