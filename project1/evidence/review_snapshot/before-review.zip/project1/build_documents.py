"""Generate evidence-led written artifacts from the same saved valuation as the app."""
import sys
from pathlib import Path
HERE=Path(__file__).resolve().parent;sys.path.insert(0,str(HERE));sys.dont_write_bytecode=True
import json,csv,shutil,re,html
from datetime import datetime,timezone
from reportlab.platypus import SimpleDocTemplate,Paragraph,Spacer,PageBreak,Table,TableStyle
from reportlab.lib.styles import getSampleStyleSheet,ParagraphStyle
from reportlab.lib import colors
from reportlab.lib.enums import TA_LEFT
from pypdf import PdfReader
import config as c

ANNOUNCEMENT='''Several students have asked about Edition A. Here is the clarification for everyone.

Keeping an accurate record of your work is a basic professional responsibility in finance and accounting. Edition A preserves your initial thinking: what you understood, what you assumed, and what you still needed to investigate. Its purpose is record keeping, even though the separate checkpoint had no grade attached.

If you have your original Edition A, preserve it unchanged and include it with your Project 1 submission. Later corrections, discoveries, and improvements belong in Edition B. Do not revise the original to make it look like what you know now.

If you no longer have the original, do not fabricate one or present a newly written document as the original. Recollect your initial thinking as honestly as you can from your best memory, clearly identify it as a retrospective recollection, and submit it with the project. Be candid about anything you cannot remember.

Continue working on your final submission. Going forward, preserve dated versions of your work so that you and others can follow how your analysis developed.

Dr. Z'''

def write(path,text):path.write_text(text.strip()+'\n',encoding='utf-8')
def money(x):return f'${x:,.2f}'
def mdtable(rows,columns):
    return '| '+' | '.join(columns)+' |\n|'+'|'.join('---' for _ in columns)+'|\n'+'\n'.join('| '+' | '.join(str(r.get(k,'')) for k in columns)+' |' for r in rows)
def pdf(source,dest,title):
    styles=getSampleStyleSheet()
    styles['Normal'].fontName='Helvetica';styles['Normal'].fontSize=9.2;styles['Normal'].leading=13
    styles['Normal'].spaceAfter=6
    styles.add(ParagraphStyle(name='SmallBody',parent=styles['Normal'],fontSize=8,leading=11))
    story=[]
    for block in source.split('\n\n'):
        block=block.strip()
        if not block:continue
        if block=='<!-- PAGEBREAK -->':story.append(PageBreak());continue
        if block.startswith('|'):
            lines=[x for x in block.splitlines() if x.startswith('|') and not re.match(r'^\|[- :|]+\|$',x)]
            data=[[Paragraph(html.escape(z.strip()).replace('**',''),styles['SmallBody']) for z in line.strip('|').split('|')] for line in lines]
            if data:
                widths=[480/len(data[0])]*len(data[0])
                t=Table(data,colWidths=widths,repeatRows=1,hAlign='LEFT')
                t.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,0),colors.HexColor('#e7eef5')),('VALIGN',(0,0),(-1,-1),'TOP'),('GRID',(0,0),(-1,-1),.3,colors.HexColor('#d5dde7')),('BOTTOMPADDING',(0,0),(-1,-1),6)]));story.extend([t,Spacer(1,9)])
            continue
        style=styles['Normal'];text=block
        if block.startswith('# '):style=styles['Title'];text=block[2:]
        elif block.startswith('## '):style=styles['Heading2'];text=block[3:]
        elif block.startswith('### '):style=styles['Heading3'];text=block[4:]
        text=html.escape(text).replace('**','').replace('`','').replace('\n','<br/>')
        story.append(Paragraph(text,style))
    def footer(canvas,doc):
        canvas.saveState();canvas.setStrokeColor(colors.HexColor('#cbd7e5'));canvas.line(42,39,570,39)
        canvas.setFont('Helvetica',8);canvas.setFillColor(colors.HexColor('#526176'))
        canvas.drawString(42,27,'FIN 43900 | AMZN | AI-assisted educational analysis | Provisional')
        canvas.drawRightString(570,27,str(doc.page));canvas.restoreState()
    SimpleDocTemplate(str(dest),pagesize=(612,792),rightMargin=60,leftMargin=60,topMargin=42,bottomMargin=50,title=title,author='Andrew Pienkos; AI-assisted draft').build(story,onFirstPage=footer,onLaterPages=footer)

def main():
    d=json.loads((HERE/'outputs/valuation.json').read_text());v=d['base']['valuation'];rows=d['base']['rows']
    validation=json.loads((HERE/'evidence/validation_summary.json').read_text())
    cold=HERE/'evidence/cold_run.json'
    coldrecord=json.loads(cold.read_text()) if cold.exists() else {'status':'NOT YET EXECUTED'}
    cases=[]
    for x in d['cases']:
        cases.append(dict(case=x['case'],funding='pass' if x['funding_feasible'] else 'FAIL',value=money(x['valuation']['per_share']) if x['valuation'] else 'unavailable',use=x['valuation_status']))
    feasible=[x['valuation']['per_share'] for x in d['cases'] if x['funding_feasible'] and x['valuation']]
    source_rows=[]
    for r in json.loads((HERE/'evidence/source_downloads.json').read_text()):
        source_rows.append(dict(id=r['id'],url=r['url'],retrieved_at_utc=r['retrieved_at_utc'],status=r.get('http_status',r.get('error')),sha256=r.get('sha256',''),path=r.get('path',''),verification='Downloaded; individual definitions checked as described in source_checks.md'))
    with (HERE/'data/source_register.csv').open('w',encoding='utf-8',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(source_rows[0]));w.writeheader();w.writerows(source_rows)
    report=f'''# Amazon investment committee application

As of {d['as_of']} regular-session close. Generated {d['generated_at_utc']}. USD millions unless stated. PROVISIONAL educational model.

## Decision and committee ask

{d['recommendation'].upper()}. {d['recommendation_reason']} {d['committee_ask']}

## Valuation and market comparison

Base signed-FCFF value {money(v['per_share'])}/share; price {money(d['price'])}; modeled gap {v['upside']:.2%}. WACC {v['wacc']:.6%}; perpetual growth {v['terminal_growth']:.2%}. Equity value {v['equity_value']:,.2f}; operating EV {v['enterprise_value']:,.2f}; diluted-share proxy {v['diluted_shares']:,.6f} million. PV explicit FCFF {v['pv_explicit']:,.2f}; PV terminal {v['pv_terminal']:,.2f}; terminal dependence {v['terminal_dependence']:.2%}.

The funded base/high subset is {money(d['valid_low_high_range'][0])}-{money(d['valid_low_high_range'][1])}; the combined low case fails funding. Across all funded named cases the observed span is {money(min(feasible))}-{money(max(feasible))}. Neither span is a complete probabilistic valuation range. Terminal dependence exceeds 100% because the discounted explicit-period FCFF sum is negative; that is an economic warning, not a percentage cap to hide.

{mdtable(cases,['case','funding','value','use'])}

## Signed FCFF and schedules

{mdtable([dict(year=r['year'],EBIT=f"{r['operating_income']:,.2f}",operating_tax=f"{r['operating_cash_taxes']:,.2f}",DA=f"{r['eligible_da']:,.2f}",investment=f"{r['operating_investment']:,.2f}",dNWC=f"{r['change_operating_wc']:,.2f}",FCFF=f"{r['fcff']:,.2f}") for r in rows],['year','EBIT','operating_tax','DA','investment','dNWC','FCFF'])}

{v['timing']} FY2025 remains the historical base. September10 aligns legacy WACC evidence and all three market closes; no October19 quote is claimed. Annual assumptions retained from later labs are retrospective analyst judgments based on sources available by the cutoff, not contemporaneously locked September predictions.

## Terminal economics

FY2031 NOPAT {v['terminal']['nopat']:,.2f}; net reinvestment {v['terminal']['net_reinvestment']:,.2f}; FCFF {v['terminal']['fcff']:,.2f}. Constant normalized operating margin and net capital ratios imply return on capital {v['terminal']['implied_return_on_capital']:.2%}. This transition reduces investment materially relative to FY2030 and needs evidence. Do not confuse internally consistent steady-state arithmetic with a supported reinvestment forecast.

{mdtable([dict(case=x['case'],value=money(x['per_share']),disposition=x['disposition']) for x in d['convention_alternatives']],['case','value','disposition'])}

## Enterprise-to-equity bridge

{mdtable([dict(item=x['item'],USDm=f"{x['value']:,.2f}") for x in v['adjustments']],['item','USDm'])}

{v['basis']} Operating lease liability {v['excluded_operating_lease_liability']:,.0f} is excluded from debt deductions because lease cash costs remain operating. Capital payables are modeled investment working capital. Private investments and their related taxes are unresolved, not assumed economically worthless.

## Comparable-company references

{mdtable([dict(multiple=k,low=money(x['low']),median=money(x['median']),high=money(x['high'])) for k,x in d['comparables']['summary'].items()],['multiple','low','median','high'])}

Walmart represents retail/membership; Microsoft represents cloud/software. Neither replicates Amazon. EV includes finance lease and minority claims; operating leases remain operating. Microsoft depreciation plus intangible amortization is sourced separately from CFO D&A-and-other. P/E uses reported annual diluted EPS and no debt subtraction. Fiscal periods, dated share counts and investment gains limit comparability. No method averaging or segment weights are invented.

## Reverse DCF

{json.dumps(d['reverse_dcf'],indent=2)}

## Reversal conditions and limitations

{d['reversal_trigger']}

'''+'\n\n'.join(d['limitations'])+f'''

## Validation and evidence

{validation['passed']} automated tests passed; {validation['failed']} failures and {validation['errors']} errors on the latest run. Earlier failed run retained. Cold-run status: {coldrecord['status']}. Automated tests do not certify personal source checks or ownership. Locked AI-off work, recordings and corrected transcripts remain student tasks.

## Sources

Amazon annual filing: {c.K}

Amazon interim filing: {c.SEC}

Amazon Q2 release: https://ir.aboutamazon.com/news-release/news-release-details/2026/Amazon-com-Announces-Second-Quarter-Results/default.aspx

Price: {c.PRICE_SOURCE}

Peer annual filings and historical market rows are in data/source_register.csv, data/peer_inputs.csv and the preserved sources directory. WACC source locators remain in lab06/lab06.md and data/assumptions.csv. Full source interpretation and exclusions are in evidence/source_checks.md.
'''
    write(HERE/'outputs/valuation-report.md',report)
    memo=f'''# Amazon | Investment committee memo

September 10, 2026 valuation; prepared October 19, 2026. USD/share unless stated. AI-assisted draft for student review.

## Decision and committee ask

WATCH/DEFER. Do not initiate under the provisional model. Request an evidence review of infrastructure returns, financing and strategic investment assets before approving capital. This is not a short recommendation or proof that the market is wrong.

## Evidence and as-of date

The signed-FCFF base is {money(v['per_share'])}, versus the {money(d['price'])} September10 close ({v['upside']:.1%} modeled gap). The funded base/high subset is {money(d['valid_low_high_range'][0])}-{money(d['valid_low_high_range'][1])}; the combined low case is unfunded, so a complete low/high range is unavailable. WACC is {v['wacc']:.2%}; g is {v['terminal_growth']:.1%}; the denominator is {v['diluted_shares']:,.3f} million diluted proxy shares.

AWS, advertising and retail service economics support the business thesis. The source register documents growing infrastructure outlays and financing needs. Growth alone does not establish returns on capital. The model derives FCFF from integrated statements, includes negative cash flows and keeps new borrowing out of operating value.

## Material assumptions and sensitivities

FY2025 reported balances anchor FY2026-2030. Existing consolidated growth, margin and capex judgments are retained. Operating leases remain rental costs; finance leases and facility financing are debt-like. New financed assets are investment; obligations are deducted once. Unlevered operating tax is a 22% provision-as-cash proxy.

Operating EV is {v['enterprise_value']/1000:,.1f} billion and common equity {v['equity_value']/1000:,.1f} billion. Terminal value supplies {v['terminal_dependence']:.1%} of operating EV. FY2031 cash flow assumes stable net capital ratios and {v['terminal']['implied_return_on_capital']:.1%} implied capital return; a material investment reduction requires evidence. The historical $32.67 FCFE lab result is not this valuation.

Comparable references are P/E {money(d['comparables']['summary']['pe']['low'])}-{money(d['comparables']['summary']['pe']['high'])}, EV/revenue {money(d['comparables']['summary']['ev_revenue']['low'])}-{money(d['comparables']['summary']['ev_revenue']['high'])}, and EV/EBITDA {money(d['comparables']['summary']['ev_ebitda']['low'])}-{money(d['comparables']['summary']['ev_ebitda']['high'])}. Walmart and Microsoft are qualified partial matches. Earnings periods and investment gains differ; no unsupported average with DCF is used.

## Principal risks, failure conditions and monitoring triggers

The combined low, AWS slowdown, infrastructure and funding stresses exhaust modeled funding. These outcomes condition the decision; accounting balance is not proof of liquidity. Monitor cash generation after investment, AWS economics, financing maturities and reserve liquidation.

The point estimate is provisional: remaining FY2026 flows are prorated uniformly; June30 bridge balances proxy September10; stock compensation is cash-replaced with a diluted-share proxy; private investments and associated tax claims are not separately valued. Their omission may materially understate equity value. Missing evidence prevents a precise fair-value claim.

## Action requested and next review point

Defer initiation. Reassess when a supported reinvestment path, financing plan and complete asset bridge survive weaker operations and support value relative to a dated price. Review at the next earnings/capital-spending disclosure. See Validation-and-AI-Use for automated results, actual AI contributions and student-only work outstanding.

Sources: Amazon FY2025 10-K (Item8; Notes3/4/6/7/10), Q2 2026 10-Q (statements; financial instruments, leases, debt and shares); Microsoft FY2026 10-K; Walmart FY2026 10-K; September10 ChartExchange closes. Direct URLs and availability dates: data/source_register.csv and evidence/source_checks.md.
'''
    write(HERE/'docs/decision-memo.md',memo)
    original=(HERE/'docs/historical/amazon-edition-a.md').read_text(encoding='utf-8')
    checkout=(HERE/'docs/historical/lab-03-checkout-draft.md').read_text(encoding='utf-8')
    evolution=f'''# Research evolution | Amazon

## Provenance and baseline status

Original September1 draft included below, with a byte-identical Markdown copy in docs/historical/amazon-edition-a.md. No Brightspace receipt or entirely AI-free authorship is claimed. The original checkout explicitly says: "I used Codex after AI use was allowed to read Amazon's SEC filing, organize filing facts, and help draft the Edition A and checkout language." The claimed timing permission is not independently established. Its unfinished receipt fields and unverified submission assertion remain historical text, not verified evidence.

The user supplied Dr. Z's October19 announcement directing students to preserve originals and continue the final submission. Its quoted text and provenance are in evidence/course_update.md. The missing receipt alone is not used to halt work. The announcement does not expressly waive early-AI recovery; that separate policy clarification remains unresolved.

## Original September1 draft | unchanged content

{original}

<!-- PAGEBREAK -->

# Edition B | October19 developments

## Later partner question

The October19 completed copy is retained separately as later evidence and does not replace the original. The user supplied: "If Amazon's AWS growth and operating cash flows slow materially over the next several years, would the company's heavy infrastructure investments still generate returns sufficient to justify the current valuation?" Its significance was added October19. No independent September1 partner provenance is claimed.

## Evolution of the model and decision

Lab06 estimated FCFF from historical cash-flow components and independent growth guesses; its result was $5.9930 and used 11.80145113% WACC. Labs07/09 included training cases. Lab08 added a qualified Walmart/Microsoft P/E comparison. Lab10 built five-year integrated statements but valued positive-only FCFE at 10%. Lab11 changed margin/capex and preserved invalid funding cases. Lab12 retained watch/defer and emphasized cash conversion and financing.

Edition B derives signed FCFF from those statements, unlevered tax and financed investment; separates operating leases from finance claims; estimates dated CAPM WACC; and builds the EV/equity bridge. It adds EV multiples, causal cases and a gross-margin reverse DCF. The new base is {money(v['per_share'])}; no code targets the historical $32.67.

| Item | Original draft / historical labs | Edition B | Driver and evidence |
|---|---|---|---|
| Decision | Watch/defer | Watch/defer with provisional range and funding conditions | Current signed-flow outputs and retained funding failures; no change forced |
| Cash-flow design | Lab06 growth path; Lab10 positive-only FCFE | Statement-derived signed FCFF | Finance definitions, independent reconciliation and negative-flow fixture |
| Date/shares | Mixed year-end and later common/diluted observations | Sep10 valuation, explicit stub and diluted proxy | Same-day peer/market rows; source availability; limitations remain |
| Main uncertainty | AWS investment returns | Reinvestment, financing and unvalued strategic assets | Stress cases, terminal dependence, lease and investment challenge |
| Partner question | Unfinished in original | Supplied and dated October19 | Later user contribution; no historical backdating |

## Thesis challenges and disposition

Growth does not guarantee cash returns. The AWS slowdown and higher-capex cases fail funding. A funded base still relies on assumed issuance and reserve liquidation. Operating lease debt cannot be deducted while leaving rental cash costs unchanged. CFO D&A-and-other is not automatically eligible EBITDA D&A. A terminal capital-turnover reset raises valuation relative to a continuing-investment diagnostic. The excluded private-asset bridge prevents a comprehensive equity-value assertion.

## What changed from Edition A to Edition B, and why?

The action remains watch/defer, but its basis is now explicit signed cash flow, financing feasibility and conditional valuation evidence. The numerical model changed substantially; uncertainty about sustainable infrastructure returns remains. This is an AI-assisted development narrative, not proof of an AI-closed baseline or a supervised assessment.
'''
    write(HERE/'docs/research-evolution.md',evolution)
    record=f'''# Validation and AI Use

## Decision, version, and as-of boundary

Watch/defer; valuation {d['as_of']}; actual run {d['generated_at_utc']}. Local uncommitted Project1 build, no push or submission. Environment in outputs/valuation.json and requirements-lock.txt. Sources available by the cutoff are distinguished from later retrieval and retrospective analyst judgments.

## Data and convention ledger

data/assumptions.csv records material inputs, sources, classifications, units, rationale and sensitivities. data/source_register.csv records actual retrievals and hashes. evidence/convention_decisions.md documents leases, capital AP, cash, securities, shares, tax and terminal alternatives. Missing or excluded assets are not asserted to have zero economic value.

## Validation register

Latest automated run: {validation['tests_run']} run, {validation['passed']} passed, {validation['failed']} failed, {validation['errors']} errors, {validation['skipped']} skipped. Command: python -B project1/tests/test_project.py. Full output: evidence/validation_results.txt. Earlier failure evidence: evidence/validation_first_run_failed.txt. All 64 preserved historical files verified unchanged.

Initial failures were (1) reverse solver bracket included an invalid terminal endpoint; (2) missing direct PP&E-addition identity check allowed a financed-investment mutation. The solver now uses a disclosed wide valid diagnostic bracket, and the accounting gate recomputes asset additions/investment. Affected and full tests were rerun successfully. These corrections fix implementation and boundary handling, not market assumptions to fit a price.

Tests cover legacy output regression, known answer, signed-flow PV, source transcription tokens and download hashes, year/BS/cash/WC/PP&E/lease/debt/equity links, two FCFF routes, WACC spread/finite inputs, bridge signs, diluted shares, terminal reinvestment, peer dates/definitions/policy, scenario isolation, restored base, reverse bounds/repricing, deliberate accounting and cash failures, and original-file preservation.

Cold run: {coldrecord['status']}. Full command/environment/first-failure record is evidence/cold_run.md. An AI-executed technical cold run does not replace an independently observed human README-only run if required by the assignment.

## Locked Changed-Input Record | NOT COMPLETED

The student must independently author the prediction before receiving AI assistance on that prediction and execute the assessed run AI closed. No assessed prediction, precommit or run is claimed. Complete evidence/locked-changed-input-template.md using a new student-selected input/perturbation; preserve actual timestamp and immutable snapshot/commit, old/new units, expected/actual direction and decision effect, and mismatch diagnosis. No commit is made by this build.

## Named AI-use register

| Tool/model surface | Interaction date | Material contribution | Independent check / disposition | Effect |
|---|---|---|---|---|
| Codex; underlying model/version not exposed in runtime evidence | October19 2026 | Architecture, code, research retrieval, assumptions organization, tests, dashboard and draft documents | Automated independent arithmetic/identity/source checks executed; student review pending | Qualified provisional valuation; no human authorship claim |
| Codex historical checkout disclosure | September1 draft metadata | Filing organization and Edition A drafting disclosed in original checkout | Preserve disclosure; no receipt or AI-free claim | Baseline status accurately qualified |
| Codex historical labs | Lab-specific dates in preserved records | Lab modeling, checking and writing | Historical records retained; not recharacterized as unaided work | Reusable technical evidence only |

| AI output/claim | Disposition | Check | Result |
|---|---|---|---|
| Positive-only FCFE as final FCFF | Reject | Inspect value_equity and cash-flow definitions | New engine retains negatives and uses WACC |
| Initial PP&E mutation gate sufficient | Correct | Deliberate financed-asset omission | Added direct identity; tests pass |
| Broad reverse bracket always evaluable | Correct | Invalid terminal endpoint and repricing tests | Explicit valid diagnostic bracket; solved economics still qualified |
| Raw CFO D&A as comparable EBITDA addback | Modify | Microsoft Notes8/10 and cash-flow statement | Separate rounded depreciation + intangible amortization |
| Base point value as precise fair value | Qualify | Stub, bridge, missing assets and terminal challenge | Provisional recommendation only |

## Independent student evidence and limitations

Student source/definition checks, assessed AI-off work, actual recordings, corrected transcripts and external link access remain pending. Automated source token checks and AI reading do not certify that the student independently verified a filing. No partner conversation or attendance is invented. Full Brightspace brief/rubric remains unverified. Separate early-AI recovery clarification is pending; the user-supplied October19 announcement supports continuing with an accurately preserved original but is not labeled an explicit recovery waiver.

## Monitoring and escalation

{d['reversal_trigger']} Stop treating the model as investable when funding is infeasible or accounting/convention checks fail. Preserve diagnostic failures rather than add unlimited financing.
'''
    write(HERE/'docs/validation-and-ai-use.md',record)
    write(HERE/'evidence/course_update.md','# October19 course update | user-supplied quotation\n\nProvenance: supplied by the student in this conversation as Dr. Z\'s announcement to all students on October19, 2026. Original Brightspace posting not independently accessed. No checkpoint receipt or AI-free authorship is inferred.\n\n'+ANNOUNCEMENT+'\n\nApplication: preserve the original and continue the final package; October19 additions belong to Edition B. Separate early-AI recovery rule is not expressly waived.')
    write(HERE/'evidence/locked-changed-input-template.md','''# Student-only Locked Changed-Input Record | NOT COMPLETED

Do not ask AI to select or draft your assessed prediction. Use a new material change you independently choose. Before execution and before AI help on the prediction, personally record: actual timestamp; immutable snapshot/commit; input; old/new values and units; finance-grounded expected direction; expected decision effect. Save the prediction unchanged. No timestamp or prediction is prefilled here.

Execute the specified test with AI closed. Preserve exact command/environment and before/after outputs. Then personally record actual direction and decision effect, explanation of any mismatch, and why the decision changed or did not change. The ordinary AI-executed scenario tests in this package do not satisfy this assessed record. Obtain permitted instructions for the required immutable snapshot if commits remain unauthorized.

## Pre-run student record

Awaiting independent student completion.

## Execution and reconciliation

Awaiting independent student completion. No run claimed.
''')
    write(HERE/'evidence/convention_decisions.md','''# Accounting and valuation conventions

## Selection and date

September10 2026 matches all peer closes and legacy dated WACC evidence. FY2025 audited statements and Q2 filed July30 were public. Original September1 thesis remains a separate historical artifact. This is a retrospective educational valuation prepared October19, not a backtest or claim that every forecast choice was locked September10. Remaining 2026 FCFF is 112/365 of full-year modeled FCFF; actual H1 and seasonality are not fully stub-reconciled. Latest available June30 bridge balances are used without pretending they are September10 observations. A precise point-in-time roll-forward remains a material improvement.

## Taxes and normalization

Reported opening balances remain unchanged. Economic operating NOPAT excludes nonoperating income and financing. No unsupported exceptional operating charge is added back. Unlevered tax is 22% of positive EBIT, inherited judgment; no automatic operating tax credit on losses. Deferred taxes, NOLs and investment-asset tax bases need further work. This is not a GAAP restatement or a claim that cash taxes equal the provision.

## Leases, investment and working capital

Operating leases remain rental expense and cash cost; no ROU addback and no operating-lease debt deduction. Finance leases/facility financing are financing claims, new assets are investment, and principal payments are excluded from FCFF. PP&E additions = cash net capex + capital AP change + finance lease additions + financed facility additions. Capital AP is investment working capital: its growth is a credit against accrued asset additions, producing cash investment plus noncash financed assets. Its liability is not separately deducted in the bridge. Neither lease additions nor debt issuance is free operating cash flow. Content/intangible replacement and amortization are assumed to offset within residual costs; no broader CFO D&A addback is made.

## Cash and investment assets

Deduct the legacy $25bn operating buffer from excess cash; reserve liquidation does not enter FCFF. Only reported cash/marketable securities are added separately. Private strategic investments and related deferred tax/commitment claims remain unvalued. Their zero supplemental adjustment means excluded, not worth zero. Published values are provisional and may materially understate equity value; no acquisition/investment funding model is invented. A $10bn supplement sensitivity is a unit effect, not an asset appraisal.

## Shares and compensation

10,786.313572m common shares July22 plus 134m Q2 incremental dilutive awards = proxy diluted valuation shares. This is not exact September10 treasury-stock dilution. Future SBC expense stays in operating costs, no addback/new issuance, under the historical cash-replacement judgment. Existing award overhang and future compensation expense are distinct, but the exact valuation treatment needs source review. EPS denominators remain annual diluted weighted-average shares in the P/E comparison.

## Terminal value

FY2031 operating margin and net invested-capital ratios stabilize; NOPAT grows at g and required net reinvestment is g times net PP&E less capital AP plus operating NWC and operating cash. Eligible D&A is added and matching replacement investment retained. The implied return on capital and sharp transition from heavy forecast investment are disclosed, not established facts. A separate carry-investment-intensity diagnostic exposes this model risk. No g/ROIC or capex assumption is tuned to a market target.

## Funding and recommendation

Report accounting validity separately from financing feasibility. Unfunded cases keep statements and diagnostic values but are excluded from investable spans. Retaining a watch/defer action is a qualified research judgment, not a mechanically justified fair-value claim. Change toward do not initiate if subsequent verified evidence establishes structural cash-return/funding failure; reconsider initiation only with complete supported value and a margin of safety.
''')
    write(HERE/'evidence/source_checks.md',f'''# Source and definition checks | AI-executed, student verification pending

Raw downloads and SHA256/actual retrievals: data/source_register.csv and evidence/source_downloads.json. Download failure retained: first Walmart annual URL returned 404; SEC index search identified accession 000010416926000055 and the corrected download returned 200. No failed source is claimed as verified.

Amazon FY2025 annual statements: revenue716924, net PPE357025, equity411065, gross PP&E cash purchases131819, proceeds3499, PPE D&A41860 and operating income79975. Historical FY2023-2025 row ledger is inherited byte-for-byte from Lab10. Q2 primary filing confirms cash78213, securities44775, finance leases13451, current/long debt face132995 plus short-term325, facility financing415+8900, Q2 incremental awards134, and common count10786313572 on July22. Book/fair-value proxies are labeled; restricted balances in other asset accounts are not added to excess cash.

Amazon FY2025 AWS sales128725 and advertising68635 are source anchors. Q2/H1 AWS growth and advertising growth motivate only the initial decomposition; future AWS/advertising paths are explicit analyst judgments, not cited guidance. Advertising sits within regional operations; the model avoids adding it a second time by making retail/other residual.

Microsoft annual revenue331839, EBIT155237 and diluted EPS17.95 are in the annual release. June30 cash20935, short-term investments55908, debt9227+31067, shares7427, finance leases66594 in annual Note13. $3.8bn restricted short-term investments are excluded from the cash offset. EBITDA uses annual Note8 depreciation $34.3bn plus Note10 intangible amortization $4.7bn (rounded) rather than the CFO D&A-and-other line38534. Other long-term investments are not credited in the simplified peer EV: this is a qualification, not proof of zero value.

Walmart FY2026 annual revenue713163, EBIT29825, D&A14203, EPS2.73; cash10727, borrowing6596, current/long debt3542+34624, finance leases856+5905 and NCI293+6270. Shares7972.402501 million on March11 cover are a dated proxy. NCI uses book proxy; operating leases remain rent. These definitions are source-read and arithmetic-tested, not claimed to be market appraisals.

Market rows: September10 closes AMZN251.89, WMT105.73, MSFT492.44 in downloaded historical tables. Treasury September10 ten-year4.95%; debt-cost5.341% from preserved July pricing term sheet. ERP5% is stipulated assumption; beta1.44 is historical vendor estimate whose method/date could not be independently reconstructed. WACC weights use same price date and dated debt proxies.

Direct filings: {c.K}; {c.SEC}; {c.PEERS[0]['source']}; {c.PEERS[1]['source']}. Other source URLs are in source_register.csv. The valuation-date availability and later retrieval are separate. A successful HTTP response or matching source token alone does not establish an independent human source check.
''')
    scripts=[
      ('1','Research evolution',3,f'''Show original Edition A and its provenance notice. Explain that the September1 watch/defer thesis concerned infrastructure cash returns; do not claim a checkpoint receipt or entirely AI-free authorship. Identify the October19 question as a later addition. Show the A-to-B table. Explain the shift from independent growth/positive-only FCFE to signed statement-derived FCFF. Demonstrate one checked AI output: financed PP&E failure and the corrected identity, or the FCFE/FCFF distinction. State the actual disposition and evidence. Conclude with what changed and why the decision remains conditional. Use your own reviewed words; this outline is AI-assisted preparation.'''),
      ('2','Code and validation',5,f'''Open README, model.py and analysis.py. Trace source register -> normalized base -> legacy statement engine -> operating tax/investment/NWC -> FCFF -> WACC/terminal -> bridge. Show exact test command and latest real log ({validation['passed']} passes). Explain one negative cash-flow fixture and the deliberate financed-asset failure. Show preserved first-run failures and corrections. Explain source and seasonality/terminal limitations. Do not say this walkthrough or ordinary automated tests satisfy the separate AI-off assessed run.'''),
      ('3','Committee defense and live demonstration',5,f'''Lead with watch/defer and ask the committee to defer initiation pending evidence. In the local dashboard show base {money(v['per_share'])}, dated price {money(d['price'])}, WACC {v['wacc']:.2%}, and the incomplete range coverage. Open scenarios, select infrastructure or AWS stress, and show the funding failure. Show signed FCFF and enterprise-to-equity bridge; explain rental leases versus debt-like finance claims. Open peers and explain fiscal/earnings differences. Show terminal/convention alternatives and unvalued private assets. End with monitoring, reversal triggers and committee ask. All displayed figures must match your final regenerated package.''')]
    for num,title,minutes,text in scripts:
        write(HERE/f'docs/video-{num}-recording-outline.md',f'# Video {num} | {title}\n\nMaximum {minutes} minutes. AI-assisted preparation; NOT an actual transcript. Record personally, use your own reviewed explanations and correct this outline if the model changes.\n\n{text}\n\nTiming guide: opening 20s; evidence demonstration approximately '+('120s' if num=='1' else '220s')+'; limitations and conclusion 30s. Leave time for transitions; verify actual duration after recording.')
        write(HERE/f'docs/transcript-video-{num}.txt',f'NOT RECORDED - TRANSCRIPT TEMPLATE ONLY\nVideo {num}: {title}\nMaximum duration: {minutes}:00\n\nAwaiting actual student recording. Replace this template with a corrected transcript matching that recording. Do not submit this placeholder as a transcript. Record actual URL, duration and evidence timestamps only after recording.')
        if num=='1':
            narration=f'''[0:00 Show the original file and provenance notice.]

My September1 written starting position was watch/defer. The question was whether Amazon's AWS growth would produce enough cash to justify its heavy infrastructure spending. The original draft is preserved unchanged in this package. It is not presented as a verified Brightspace checkpoint or entirely AI-free work: the original checkout disclosed Codex drafting assistance.

[0:35 Show the later addition and research-evolution table.]

The partner falsification question was supplied for addition on October19. It asks whether infrastructure returns would justify valuation if AWS and operating cash flows slowed materially. That later question does not replace the historical draft. The professor's announcement, supplied in the conversation, directed students to preserve the original and continue; the separate early-AI recovery issue remains accurately disclosed.

[1:05 Show signed FCFF and the failed accounting fixture.]

The model evolved from independent cash-flow growth guesses in Lab06 and positive-only FCFE in Lab10 to statement-derived signed FCFF. Financing and reserve sales do not become operating cash flow. One AI-generated implementation initially missed a mutation in financed PP&E additions. The deliberate failure test exposed that gap; the corrected identity now checks financed investment directly. The actual failed and passing logs are retained. This is an automated check, not my separate assessed AI-off record.

[2:00 Show conclusion and limitations.]

The provisional new base is {money(v['per_share'])}, and the action remains watch/defer. What changed is the evidence supporting the conditions: funding failure, terminal reinvestment and an incomplete investment-asset bridge now matter explicitly. Before submission I must review the judgments, complete my independent assessment and record the actual videos. No historical evidence is reconstructed to make the story cleaner.'''
        elif num=='2':
            narration=f'''[0:00 Open README and repository map.]

This application values Amazon using five-year integrated statements and operating FCFF. It is a local, uncommitted Edition B package. The README shows the tested portable Python commands and a standard-venv alternative. Sources and saved outputs are included so a reviewer can inspect the result without executing code.

[0:40 Open model.py and statement output.]

The statement engine reuses the preserved Lab10 code without editing it. The data register retains reported history separately from economic normalization. Statements calculate operating profit, financing, investment, working capital and cash in order. Cash comes from the cash-flow statement; it is never a balancing plug. Borrowing and securities sales support funding but do not enter FCFF.

[1:25 Show FCFF reconciliation and bridge.]

Operating FCFF equals EBIT less unlevered operating tax, plus eligible depreciation, less investment and the change in operating working capital. Negative flows remain signed. Finance-lease additions are investment while principal is financing. Operating leases remain rental costs; their liability is not deducted a second time. Capital payables supply investment working-capital credit. The enterprise-to-equity bridge separates excess cash, securities, debt and finance claims and uses an explicitly qualified diluted-share proxy.

[2:20 Show commands and actual logs.]

The automated suite now has {validation['passed']} passing tests. It reproduces the legacy statement output, reconciles a known-answer DCF, checks negative cash flows and tests accounting identities, bridge definitions, peers and solver bounds. The first run's failures are preserved. In particular, omitting a financed asset must fail the PP&E identity. The fresh-environment technical run and seven dashboard-page executions are separate reproducibility evidence.

[3:20 Show limitations and assessed-work template.]

Passing arithmetic checks does not verify forecast accuracy. Remaining 2026 cash flow is prorated rather than seasonally modeled; the bridge uses the latest reported balances; private investments and related claims are unvalued; and the terminal transition needs evidence. Student source verification and the genuinely AI-off Locked Changed-Input Record remain separate. This walkthrough does not claim that those activities happened. The package records material AI help and identifies exactly what still needs my own work.'''
        else:
            narration=f'''[0:00 Decision page, lead with committee ask.]

My recommendation is watch/defer. I ask the committee to defer initiation until the infrastructure return, financing and investment-asset evidence is sufficient to support a complete valuation. This provisional model does not establish that the market is wrong and does not support a short recommendation.

[0:30 Show base and dated market comparison.]

The signed-FCFF base is {money(v['per_share'])} against the September10 close of {money(d['price'])}. WACC is {v['wacc']:.2%} and perpetual growth is {v['terminal_growth']:.1%}. These are dated model inputs, not a live quote. The funded base/high subset reaches {money(d['valid_low_high_range'][1])}; the low case is infeasible, so there is no complete low/high investment interval.

[1:10 Open financial statements and FCFF tab.]

AWS, advertising and retail services support operating growth, but infrastructure turns those prospects into immediate cash outlays. The five-year forecast retains negative FCFF and excludes financing receipts from operating value. Borrowing can keep cash above a floor without proving that investment is self-funded.

[1:50 Demonstrate a funding stress.]

Here is the infrastructure or AWS stress. The model retains the cash-floor failure instead of assuming unlimited financing. Its value is a diagnostic, not an investable scenario endpoint. The committee should monitor incremental operating cash after infrastructure spending, the use of securities reserves and the availability of financing.

[2:35 Demonstrate bridge and peer references.]

Operating leases stay in operating costs, whereas finance-lease claims are deducted consistently with investment treatment. Walmart and Microsoft provide qualified retail and cloud references, but their fiscal periods and investment gains differ. Enterprise multiples need an equity bridge; P/E does not. I do not average the methods to hide disagreement.

[3:25 Show terminal and limitations.]

Terminal value contributes {v['terminal_dependence']:.1%} of operating EV because explicit-period present value is negative. That concentration and the assumed terminal investment reduction are central risks. The uniform remaining-year timing, dated balance proxies and omitted private investment value prevent precise fair-value claims. I would revisit initiation only after a supported reinvestment plan, feasible funding and complete asset bridge survive weaker operations and leave an evidence-supported margin of safety. Verified structural funding or cash-return failure would move the decision toward do not initiate. The committee ask today is to defer and specify that next evidence review.'''
        write(HERE/f'docs/video-{num}-script.md',f'# Video {num} draft script | NOT A TRANSCRIPT\n\nAI-assisted recording preparation. Review and speak in your own words. Do not claim independent checks you have not performed. Approximate timing only; verify actual duration after recording.\n\n'+narration)
    for name,title in [('decision-memo','Investment committee memo'),('research-evolution','Research evolution'),('validation-and-ai-use','Validation and AI use')]:
        pdf((HERE/f'docs/{name}.md').read_text(encoding='utf-8'),HERE/f'docs/{name}.pdf',title)
    pages=len(PdfReader(HERE/'docs/decision-memo.pdf').pages)
    if pages>2:raise ValueError(f'Memo exceeds two pages: {pages}')
    for src,dst in [('decision-memo','Decision-Memo'),('research-evolution','Research-Evolution'),('validation-and-ai-use','Validation-and-AI-Use')]:
        shutil.copyfile(HERE/f'docs/{src}.pdf',HERE/f'submission/{dst}.pdf')
    manifest_template=Path('C:/Users/acpie/Documents/Codex/fin439-lab07-course/projects/templates/project-submission-manifest-template.csv')
    with manifest_template.open(encoding='utf-8',newline='') as f:manifest=list(csv.DictReader(f))
    locations={'Research-Evolution.pdf':'Research-Evolution.pdf','Repository':'https://github.com/acpienkos/Amazon-Report','Visible executed output':'../outputs/valuation-report.md','Decision memo or deck':'Decision-Memo.pdf','Validation-and-AI-Use.pdf':'Validation-and-AI-Use.pdf'}
    for row in manifest:
        item=row['item'];row['duration_or_as_of']=d['as_of'];row['frozen_or_commit_id']='Local uncommitted build; not uploaded'
        row['location_or_url']=locations.get(item,'');row['access_checked']='Local file only' if item!='Repository' and item in locations else 'Not verified for final package'
        row['status']='LOCAL DRAFT / STUDENT REVIEW REQUIRED' if item in locations else 'AWAITING STUDENT ACTION'
        row['notes']='Local additions are not on GitHub. No submission receipt claimed.'
        if item=='Validation-and-AI-Use.pdf':row['notes']='Automated evidence included; student AI-off record and source verification pending.'
        if item.startswith('Transcript'):
            n=item[-1];row['location_or_url']=f'../docs/transcript-video-{n}.txt';row['notes']='Template only, not completed transcript.'
        if item.startswith('Video '):row['notes']='Await actual recording, stable URL, title, duration, timestamps and access check.'
        if item=='Optional deployed output':row['status']='NOT REQUIRED / NOT DEPLOYED';row['notes']='No deployment authorized.'
    with (HERE/'submission/project-submission-manifest.csv').open('w',encoding='utf-8',newline='') as f:
        writer=csv.DictWriter(f,fieldnames=list(manifest[0]));writer.writeheader();writer.writerows(manifest)
    print(f'Written artifacts generated. Memo: {pages} pages. Student evidence and videos remain incomplete.')

if __name__=='__main__':main()
