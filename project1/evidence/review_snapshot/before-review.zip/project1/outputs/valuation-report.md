# Amazon investment committee application

As of 2026-09-10 regular-session close. Generated 2026-10-19T19:24:04.350458+00:00. USD millions unless stated. PROVISIONAL educational model.

## Decision and committee ask

WATCH/DEFER. Do not initiate a position under the provisional model. Retain watch/defer until funding, reinvestment, asset bridge and market-implied margin evidence are resolved. Defer initiation; authorize further evidence review of infrastructure cash returns, funding and non-operating assets.

## Valuation and market comparison

Base signed-FCFF value $40.74/share; price $251.89; modeled gap -83.83%. WACC 11.738108%; perpetual growth 2.50%. Equity value 444,924.00; operating EV 503,022.00; diluted-share proxy 10,920.313572 million. PV explicit FCFF -66,361.31; PV terminal 569,383.31; terminal dependence 113.19%.

The funded base/high subset is $40.74-$58.96; the combined low case fails funding. Across all funded named cases the observed span is $33.50-$58.96. Neither span is a complete probabilistic valuation range. Terminal dependence exceeds 100% because the discounted explicit-period FCFF sum is negative; that is an economic warning, not a percentage cap to hide.

| case | funding | value | use |
|---|---|---|---|
| base | pass | $40.74 | provisional |
| low | FAIL | $4.54 | diagnostic only - infeasible or invalid |
| high | pass | $58.96 | provisional |
| aws_slowdown | FAIL | $22.10 | diagnostic only - infeasible or invalid |
| infrastructure_stress | FAIL | $29.77 | diagnostic only - infeasible or invalid |
| margin_downside | pass | $33.50 | provisional |
| funding_stress | FAIL | $40.74 | diagnostic only - infeasible or invalid |

## Signed FCFF and schedules

| year | EBIT | operating_tax | DA | investment | dNWC | FCFF |
|---|---|---|---|---|---|---|
| 2026 | 95,724.45 | 21,059.38 | 53,553.75 | 222,911.00 | -9,807.43 | -84,884.75 |
| 2027 | 98,542.38 | 21,679.32 | 81,850.92 | 232,911.00 | -9,274.65 | -64,922.38 |
| 2028 | 108,316.01 | 23,829.52 | 104,825.55 | 222,911.00 | -8,667.02 | -24,931.94 |
| 2029 | 119,189.13 | 26,221.61 | 122,222.75 | 212,911.00 | -8,566.85 | 10,846.12 |
| 2030 | 132,404.53 | 29,129.00 | 135,510.37 | 202,911.00 | -7,279.22 | 43,154.12 |

Sept10 2026; remaining 112/365 of modeled FY2026 FCFF, then full FY2027-2030. Uniform accrual proxy; excludes elapsed cashflows; does not forecast seasonality. FY2025 remains the historical base. September10 aligns legacy WACC evidence and all three market closes; no October19 quote is claimed. Annual assumptions retained from later labs are retrospective analyst judgments based on sources available by the cutoff, not contemporaneously locked September predictions.

## Terminal economics

FY2031 NOPAT 105,857.42; net reinvestment 21,020.76; FCFF 84,836.66. Constant normalized operating margin and net capital ratios imply return on capital 12.59%. This transition reduces investment materially relative to FY2030 and needs evidence. Do not confuse internally consistent steady-state arithmetic with a supported reinvestment forecast.

| case | value | disposition |
|---|---|---|
| All cash treated excess | $43.03 | Not base; operating cash judgment |
| Double-count operating lease debt (REJECTED) | $31.92 | Reject: rental cost already in EBIT/FCFF |
| Per $10bn net nonoperating asset supplement | $41.66 | Unit sensitivity only; supplement remains unvalued |
| Carry FY2030 investment intensity into terminal (diagnostic) | $12.56 | Avoids immediate capital-turnover reset but not a fully reconciled perpetual asset schedule; shows terminal-model risk. |

## Enterprise-to-equity bridge

| item | USDm |
|---|---|
| Cash and equivalents | 78,213.00 |
| Required operating cash | -25,000.00 |
| Marketable securities | 44,775.00 |
| Debt incl current/short term | -133,320.00 |
| Finance leases | -13,451.00 |
| Facility financing | -9,315.00 |
| Non-operating asset supplement | 0.00 |
| Other separate claims | 0.00 |

Latest available June30 balances; July22 common shares plus Q2 incremental diluted awards. Not exact September10 balances. Operating lease liability 96,320 is excluded from debt deductions because lease cash costs remain operating. Capital payables are modeled investment working capital. Private investments and their related taxes are unresolved, not assumed economically worthless.

## Comparable-company references

| multiple | low | median | high |
|---|---|---|---|
| ev_revenue | $76.63 | $400.79 | $724.94 |
| ev_ebitda | $206.70 | $213.49 | $220.28 |
| pe | $196.70 | $237.19 | $277.69 |

Walmart represents retail/membership; Microsoft represents cloud/software. Neither replicates Amazon. EV includes finance lease and minority claims; operating leases remain operating. Microsoft depreciation plus intangible amortization is sourced separately from CFO D&A-and-other. P/E uses reported annual diluted EPS and no debt subtraction. Fiscal periods, dated share counts and investment gains limit comparability. No method averaging or segment weights are invented.

## Reverse DCF

{
  "target": 251.89,
  "variable": "Uniform additive gross-margin shift, decimal ratio",
  "held_fixed": "Revenue paths, capex, working capital policies, financing assumptions, WACC, g, bridge and shares.",
  "bounds": [
    -0.01,
    0.3
  ],
  "endpoint_prices": [
    33.500395603059594,
    258.01450828650013
  ],
  "solution": 0.2915435268077999,
  "repriced": 251.88999997947397,
  "funding_feasible": true,
  "gross_margin_path": [
    0.8015435268077999,
    0.8115435268078,
    0.8215435268078,
    0.8265435268077999,
    0.8315435268078
  ],
  "status": "Conditional solution; not proof of feasible margins or mispricing"
}

## Reversal conditions and limitations

Reassess only after supported signed-flow value and funding survive conservative reinvestment/operating cases, and the dated price offers an evidence-supported margin of safety.

PROVISIONAL: annual FY2026 FCFF is accrued uniformly for the 112-day remaining stub. Amazon seasonality and actual H1 cashflows are not fully reconciled to an intra-year valuation.

Bridge uses latest available June30 reported cash/debt/leases; it is not an exact September10 roll-forward. Test stale-balance alternatives before an investment.

Private strategic investments, embedded tax liabilities and commitments are not separately valued; zero supplement means excluded, not worth zero. This can materially understate equity value.

Gross-margin, capex taper, funding renewal, AWS/advertising decomposition and terminal reinvestment are analyst judgments; no probabilities assigned.

Normalized operating cash tax equals 22% of positive EBIT; deferred taxes and NOL use are not explicitly scheduled. Reported paid taxes are not equivalent.

Operating leases remain rent in EBIT/FCFF and are not deducted again. Finance leases/facility additions are investment; liabilities are deducted once. Content replacement/amortization net to zero in residual operating expense.

Diluted shares use July22 common shares plus Q2 incremental awards; this is a proxy. Future compensation is cash-replaced, not actual Amazon policy.

Beta 1.44 is the preserved September10 vendor observation; its historical estimation process could not be independently reconstructed. ERP 5% is a course assumption, not observed data.

Full Brightspace assignment/rubric and the October19 announcement original posting were not accessed. Announcement is reproduced as user-supplied course evidence; early-AI recovery remains a separate clarification.

New outputs are AI-assisted. No human AI-off prediction, assessed execution, actual recording or corrected transcript is claimed.

## Validation and evidence

49 automated tests passed; 0 failures and 0 errors on the latest run. Earlier failed run retained. Cold-run status: PASS. Automated tests do not certify personal source checks or ownership. Locked AI-off work, recordings and corrected transcripts remain student tasks.

## Sources

Amazon annual filing: https://www.sec.gov/Archives/edgar/data/1018724/000101872426000004/amzn-20251231.htm

Amazon interim filing: https://www.sec.gov/Archives/edgar/data/1018724/000101872426000026/amzn-20260630.htm

Amazon Q2 release: https://ir.aboutamazon.com/news-release/news-release-details/2026/Amazon-com-Announces-Second-Quarter-Results/default.aspx

Price: https://chartexchange.com/symbol/nasdaq-amzn/historical/

Peer annual filings and historical market rows are in data/source_register.csv, data/peer_inputs.csv and the preserved sources directory. WACC source locators remain in lab06/lab06.md and data/assumptions.csv. Full source interpretation and exclusions are in evidence/source_checks.md.
