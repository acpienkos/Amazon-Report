# Video 3 | Committee defense and live demonstration

Maximum 5 minutes. AI-assisted preparation; NOT an actual transcript. Record personally, use your own reviewed explanations and correct this outline if the model changes.

Lead with watch/defer and ask the committee to defer initiation pending evidence. In the local dashboard show base $40.74, dated price $251.89, WACC 11.74%, and the incomplete range coverage. Open scenarios, select infrastructure or AWS stress, and show the funding failure. Show signed FCFF and enterprise-to-equity bridge; explain rental leases versus debt-like finance claims. Open peers and explain fiscal/earnings differences. Show terminal/convention alternatives and unvalued private assets. End with monitoring, reversal triggers and committee ask. All displayed figures must match your final regenerated package.

Timing guide: opening 20s; evidence demonstration approximately 220s; limitations and conclusion 30s. Leave time for transitions; verify actual duration after recording.
