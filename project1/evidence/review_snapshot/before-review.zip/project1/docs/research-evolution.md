# Research evolution | Amazon

## Provenance and baseline status

Original September1 draft included below, with a byte-identical Markdown copy in docs/historical/amazon-edition-a.md. No Brightspace receipt or entirely AI-free authorship is claimed. The original checkout explicitly says: "I used Codex after AI use was allowed to read Amazon's SEC filing, organize filing facts, and help draft the Edition A and checkout language." The claimed timing permission is not independently established. Its unfinished receipt fields and unverified submission assertion remain historical text, not verified evidence.

The user supplied Dr. Z's October19 announcement directing students to preserve originals and continue the final submission. Its quoted text and provenance are in evidence/course_update.md. The missing receipt alone is not used to halt work. The announcement does not expressly waive early-AI recovery; that separate policy clarification remains unresolved.

## Original September1 draft | unchanged content

# Project 1 Valuation — Edition A

## Decision and user

I am looking at Amazon to decide whether it is worth continuing with a full valuation for Project 1. The intended user is me acting as a student equity-research analyst. My decision is whether to initiate research now, wait for more information, or stop considering the company.

## Company and valuation date

- Company: Amazon.com, Inc.
- Ticker: AMZN
- Valuation date: September 1, 2026
- Initial decision: Watch/defer

## Initial thesis

My starting opinion is **watch/defer**. Amazon is growing, especially in AWS, and has a large amount of cash. However, it also has a large amount of debt and is spending heavily on technology and infrastructure. I want to understand whether its future cash flow can support that spending before making a stronger decision.

## Known evidence

Amazon's Form 10-Q covers the quarter ended June 30, 2026 and was filed July 30, 2026. The accession number is 0001018724-26-000026. The statements are in U.S. dollars and mainly reported in millions.

Amazon reported $200.606 billion of total net sales for the three months ended June 30, 2026, compared with $167.702 billion in the same quarter of 2025. AWS sales were $42.232 billion, compared with $30.873 billion in the same quarter of 2025. Amazon said AWS sales increased 37% because of increased customer usage, partly offset by pricing changes.

At June 30, 2026, Amazon reported $78.213 billion in cash and cash equivalents and $44.775 billion in marketable securities. It reported $132.995 billion as the face value of long-term debt, including a $3.330 billion current portion. Long-term debt shown on the balance sheet after the current portion and issuance adjustments was $128.894 billion.

The diluted-share figure was 10.903 billion weighted-average shares for the second quarter of 2026. I am using diluted weighted-average shares because they include the effect of potentially dilutive stock awards and are more complete than basic shares for a per-share valuation.

Primary source: Amazon.com, Inc., Form 10-Q for the quarter ended June 30, 2026, filed July 30, 2026: https://www.sec.gov/Archives/edgar/data/1018724/000101872426000026/amzn-20260630.htm

## Consequential assumptions

- AWS will continue growing, although probably not at exactly the current 37% rate.
- Amazon will turn enough of its sales into operating cash flow to support its investments.
- Technology and infrastructure spending will eventually produce useful returns.
- I will treat cash, debt, leases, and investments consistently when moving from enterprise value to equity value.

## Unknowns

- I do not yet know what a reasonable long-term AWS growth rate should be.
- I do not yet know how much of Amazon's current investment spending is temporary.
- I need to decide how leases and non-operating investments should be handled in the valuation.
- I do not yet have a discount rate or a finished free-cash-flow forecast.
- I do not yet know whether Amazon looks overvalued or undervalued at the valuation date.

## Research plan

1. Review Amazon's cash-flow statement and separate normal spending from unusually high investment spending.
2. Compare AWS growth and margins with earlier periods.
3. Build simple revenue, operating-margin, and free-cash-flow forecasts.
4. Estimate a discount rate and terminal-growth rate.
5. Complete the enterprise-to-equity bridge using consistent cash, debt, lease, and share-count definitions.
6. Test how the result changes when AWS growth, margins, and the discount rate change.

## Partner falsification question

**Partner's question:** [Enter the exact question your partner gives you.]

**Why it matters:** [Explain in one sentence how a bad answer could change your watch/defer decision.]



<!-- PAGEBREAK -->

# Edition B | October19 developments

## Later partner question

The October19 completed copy is retained separately as later evidence and does not replace the original. The user supplied: "If Amazon's AWS growth and operating cash flows slow materially over the next several years, would the company's heavy infrastructure investments still generate returns sufficient to justify the current valuation?" Its significance was added October19. No independent September1 partner provenance is claimed.

## Evolution of the model and decision

Lab06 estimated FCFF from historical cash-flow components and independent growth guesses; its result was $5.9930 and used 11.80145113% WACC. Labs07/09 included training cases. Lab08 added a qualified Walmart/Microsoft P/E comparison. Lab10 built five-year integrated statements but valued positive-only FCFE at 10%. Lab11 changed margin/capex and preserved invalid funding cases. Lab12 retained watch/defer and emphasized cash conversion and financing.

Edition B derives signed FCFF from those statements, unlevered tax and financed investment; separates operating leases from finance claims; estimates dated CAPM WACC; and builds the EV/equity bridge. It adds EV multiples, causal cases and a gross-margin reverse DCF. The new base is $40.74; no code targets the historical $32.67.

| Item | Original draft / historical labs | Edition B | Driver and evidence |
|---|---|---|---|
| Decision | Watch/defer | Watch/defer with provisional range and funding conditions | Current signed-flow outputs and retained funding failures; no change forced |
| Cash-flow design | Lab06 growth path; Lab10 positive-only FCFE | Statement-derived signed FCFF | Finance definitions, independent reconciliation and negative-flow fixture |
| Date/shares | Mixed year-end and later common/diluted observations | Sep10 valuation, explicit stub and diluted proxy | Same-day peer/market rows; source availability; limitations remain |
| Main uncertainty | AWS investment returns | Reinvestment, financing and unvalued strategic assets | Stress cases, terminal dependence, lease and investment challenge |
| Partner question | Unfinished in original | Supplied and dated October19 | Later user contribution; no historical backdating |

## Thesis challenges and disposition

Growth does not guarantee cash returns. The AWS slowdown and higher-capex cases fail funding. A funded base still relies on assumed issuance and reserve liquidation. Operating lease debt cannot be deducted while leaving rental cash costs unchanged. CFO D&A-and-other is not automatically eligible EBITDA D&A. A terminal capital-turnover reset raises valuation relative to a continuing-investment diagnostic. The excluded private-asset bridge prevents a comprehensive equity-value assertion.

## What changed from Edition A to Edition B, and why?

The action remains watch/defer, but its basis is now explicit signed cash flow, financing feasibility and conditional valuation evidence. The numerical model changed substantially; uncertainty about sustainable infrastructure returns remains. This is an AI-assisted development narrative, not proof of an AI-closed baseline or a supervised assessment.
