# Video 3 draft script | NOT A TRANSCRIPT

AI-assisted recording preparation. Review and speak in your own words. Do not claim independent checks you have not performed. Approximate timing only; verify actual duration after recording.

[0:00 Decision page, lead with committee ask.]

My recommendation is watch/defer. I ask the committee to defer initiation until the infrastructure return, financing and investment-asset evidence is sufficient to support a complete valuation. This provisional model does not establish that the market is wrong and does not support a short recommendation.

[0:30 Show base and dated market comparison.]

The signed-FCFF base is $40.74 against the September10 close of $251.89. WACC is 11.74% and perpetual growth is 2.5%. These are dated model inputs, not a live quote. The funded base/high subset reaches $58.96; the low case is infeasible, so there is no complete low/high investment interval.

[1:10 Open financial statements and FCFF tab.]

AWS, advertising and retail services support operating growth, but infrastructure turns those prospects into immediate cash outlays. The five-year forecast retains negative FCFF and excludes financing receipts from operating value. Borrowing can keep cash above a floor without proving that investment is self-funded.

[1:50 Demonstrate a funding stress.]

Here is the infrastructure or AWS stress. The model retains the cash-floor failure instead of assuming unlimited financing. Its value is a diagnostic, not an investable scenario endpoint. The committee should monitor incremental operating cash after infrastructure spending, the use of securities reserves and the availability of financing.

[2:35 Demonstrate bridge and peer references.]

Operating leases stay in operating costs, whereas finance-lease claims are deducted consistently with investment treatment. Walmart and Microsoft provide qualified retail and cloud references, but their fiscal periods and investment gains differ. Enterprise multiples need an equity bridge; P/E does not. I do not average the methods to hide disagreement.

[3:25 Show terminal and limitations.]

Terminal value contributes 113.2% of operating EV because explicit-period present value is negative. That concentration and the assumed terminal investment reduction are central risks. The uniform remaining-year timing, dated balance proxies and omitted private investment value prevent precise fair-value claims. I would revisit initiation only after a supported reinvestment plan, feasible funding and complete asset bridge survive weaker operations and leave an evidence-supported margin of safety. Verified structural funding or cash-return failure would move the decision toward do not initiate. The committee ask today is to defer and specify that next evidence review.
