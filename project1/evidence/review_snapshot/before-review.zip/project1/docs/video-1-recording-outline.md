# Video 1 | Research evolution

Maximum 3 minutes. AI-assisted preparation; NOT an actual transcript. Record personally, use your own reviewed explanations and correct this outline if the model changes.

Show original Edition A and its provenance notice. Explain that the September1 watch/defer thesis concerned infrastructure cash returns; do not claim a checkpoint receipt or entirely AI-free authorship. Identify the October19 question as a later addition. Show the A-to-B table. Explain the shift from independent growth/positive-only FCFE to signed statement-derived FCFF. Demonstrate one checked AI output: financed PP&E failure and the corrected identity, or the FCFE/FCFF distinction. State the actual disposition and evidence. Conclude with what changed and why the decision remains conditional. Use your own reviewed words; this outline is AI-assisted preparation.

Timing guide: opening 20s; evidence demonstration approximately 120s; limitations and conclusion 30s. Leave time for transitions; verify actual duration after recording.
