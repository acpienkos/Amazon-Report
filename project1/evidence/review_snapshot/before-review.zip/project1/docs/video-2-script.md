# Video 2 draft script | NOT A TRANSCRIPT

AI-assisted recording preparation. Review and speak in your own words. Do not claim independent checks you have not performed. Approximate timing only; verify actual duration after recording.

[0:00 Open README and repository map.]

This application values Amazon using five-year integrated statements and operating FCFF. It is a local, uncommitted Edition B package. The README shows the tested portable Python commands and a standard-venv alternative. Sources and saved outputs are included so a reviewer can inspect the result without executing code.

[0:40 Open model.py and statement output.]

The statement engine reuses the preserved Lab10 code without editing it. The data register retains reported history separately from economic normalization. Statements calculate operating profit, financing, investment, working capital and cash in order. Cash comes from the cash-flow statement; it is never a balancing plug. Borrowing and securities sales support funding but do not enter FCFF.

[1:25 Show FCFF reconciliation and bridge.]

Operating FCFF equals EBIT less unlevered operating tax, plus eligible depreciation, less investment and the change in operating working capital. Negative flows remain signed. Finance-lease additions are investment while principal is financing. Operating leases remain rental costs; their liability is not deducted a second time. Capital payables supply investment working-capital credit. The enterprise-to-equity bridge separates excess cash, securities, debt and finance claims and uses an explicitly qualified diluted-share proxy.

[2:20 Show commands and actual logs.]

The automated suite now has 49 passing tests. It reproduces the legacy statement output, reconciles a known-answer DCF, checks negative cash flows and tests accounting identities, bridge definitions, peers and solver bounds. The first run's failures are preserved. In particular, omitting a financed asset must fail the PP&E identity. The fresh-environment technical run and seven dashboard-page executions are separate reproducibility evidence.

[3:20 Show limitations and assessed-work template.]

Passing arithmetic checks does not verify forecast accuracy. Remaining 2026 cash flow is prorated rather than seasonally modeled; the bridge uses the latest reported balances; private investments and related claims are unvalued; and the terminal transition needs evidence. Student source verification and the genuinely AI-off Locked Changed-Input Record remain separate. This walkthrough does not claim that those activities happened. The package records material AI help and identifies exactly what still needs my own work.
