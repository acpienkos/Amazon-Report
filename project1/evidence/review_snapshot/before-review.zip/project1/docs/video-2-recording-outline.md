# Video 2 | Code and validation

Maximum 5 minutes. AI-assisted preparation; NOT an actual transcript. Record personally, use your own reviewed explanations and correct this outline if the model changes.

Open README, model.py and analysis.py. Trace source register -> normalized base -> legacy statement engine -> operating tax/investment/NWC -> FCFF -> WACC/terminal -> bridge. Show exact test command and latest real log (49 passes). Explain one negative cash-flow fixture and the deliberate financed-asset failure. Show preserved first-run failures and corrections. Explain source and seasonality/terminal limitations. Do not say this walkthrough or ordinary automated tests satisfy the separate AI-off assessed run.

Timing guide: opening 20s; evidence demonstration approximately 220s; limitations and conclusion 30s. Leave time for transitions; verify actual duration after recording.
