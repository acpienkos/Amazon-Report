# Amazon | Investment committee memo

September 10, 2026 valuation; prepared October 19, 2026. USD/share unless stated. AI-assisted draft for student review.

## Decision and committee ask

WATCH/DEFER. Do not initiate under the provisional model. Request an evidence review of infrastructure returns, financing and strategic investment assets before approving capital. This is not a short recommendation or proof that the market is wrong.

## Evidence and as-of date

The signed-FCFF base is $40.74, versus the $251.89 September10 close (-83.8% modeled gap). The funded base/high subset is $40.74-$58.96; the combined low case is unfunded, so a complete low/high range is unavailable. WACC is 11.74%; g is 2.5%; the denominator is 10,920.314 million diluted proxy shares.

AWS, advertising and retail service economics support the business thesis. The source register documents growing infrastructure outlays and financing needs. Growth alone does not establish returns on capital. The model derives FCFF from integrated statements, includes negative cash flows and keeps new borrowing out of operating value.

## Material assumptions and sensitivities

FY2025 reported balances anchor FY2026-2030. Existing consolidated growth, margin and capex judgments are retained. Operating leases remain rental costs; finance leases and facility financing are debt-like. New financed assets are investment; obligations are deducted once. Unlevered operating tax is a 22% provision-as-cash proxy.

Operating EV is 503.0 billion and common equity 444.9 billion. Terminal value supplies 113.2% of operating EV. FY2031 cash flow assumes stable net capital ratios and 12.6% implied capital return; a material investment reduction requires evidence. The historical $32.67 FCFE lab result is not this valuation.

Comparable references are P/E $196.70-$277.69, EV/revenue $76.63-$724.94, and EV/EBITDA $206.70-$220.28. Walmart and Microsoft are qualified partial matches. Earnings periods and investment gains differ; no unsupported average with DCF is used.

## Principal risks, failure conditions and monitoring triggers

The combined low, AWS slowdown, infrastructure and funding stresses exhaust modeled funding. These outcomes condition the decision; accounting balance is not proof of liquidity. Monitor cash generation after investment, AWS economics, financing maturities and reserve liquidation.

The point estimate is provisional: remaining FY2026 flows are prorated uniformly; June30 bridge balances proxy September10; stock compensation is cash-replaced with a diluted-share proxy; private investments and associated tax claims are not separately valued. Their omission may materially understate equity value. Missing evidence prevents a precise fair-value claim.

## Action requested and next review point

Defer initiation. Reassess when a supported reinvestment path, financing plan and complete asset bridge survive weaker operations and support value relative to a dated price. Review at the next earnings/capital-spending disclosure. See Validation-and-AI-Use for automated results, actual AI contributions and student-only work outstanding.

Sources: Amazon FY2025 10-K (Item8; Notes3/4/6/7/10), Q2 2026 10-Q (statements; financial instruments, leases, debt and shares); Microsoft FY2026 10-K; Walmart FY2026 10-K; September10 ChartExchange closes. Direct URLs and availability dates: data/source_register.csv and evidence/source_checks.md.
