# Validation and AI Use

## Decision, version, and as-of boundary

Watch/defer; valuation 2026-09-10; actual run 2026-10-19T19:24:04.350458+00:00. Local uncommitted Project1 build, no push or submission. Environment in outputs/valuation.json and requirements-lock.txt. Sources available by the cutoff are distinguished from later retrieval and retrospective analyst judgments.

## Data and convention ledger

data/assumptions.csv records material inputs, sources, classifications, units, rationale and sensitivities. data/source_register.csv records actual retrievals and hashes. evidence/convention_decisions.md documents leases, capital AP, cash, securities, shares, tax and terminal alternatives. Missing or excluded assets are not asserted to have zero economic value.

## Validation register

Latest automated run: 49 run, 49 passed, 0 failed, 0 errors, 0 skipped. Command: python -B project1/tests/test_project.py. Full output: evidence/validation_results.txt. Earlier failure evidence: evidence/validation_first_run_failed.txt. All 64 preserved historical files verified unchanged.

Initial failures were (1) reverse solver bracket included an invalid terminal endpoint; (2) missing direct PP&E-addition identity check allowed a financed-investment mutation. The solver now uses a disclosed wide valid diagnostic bracket, and the accounting gate recomputes asset additions/investment. Affected and full tests were rerun successfully. These corrections fix implementation and boundary handling, not market assumptions to fit a price.

Tests cover legacy output regression, known answer, signed-flow PV, source transcription tokens and download hashes, year/BS/cash/WC/PP&E/lease/debt/equity links, two FCFF routes, WACC spread/finite inputs, bridge signs, diluted shares, terminal reinvestment, peer dates/definitions/policy, scenario isolation, restored base, reverse bounds/repricing, deliberate accounting and cash failures, and original-file preservation.

Cold run: PASS. Full command/environment/first-failure record is evidence/cold_run.md. An AI-executed technical cold run does not replace an independently observed human README-only run if required by the assignment.

## Locked Changed-Input Record | NOT COMPLETED

The student must independently author the prediction before receiving AI assistance on that prediction and execute the assessed run AI closed. No assessed prediction, precommit or run is claimed. Complete evidence/locked-changed-input-template.md using a new student-selected input/perturbation; preserve actual timestamp and immutable snapshot/commit, old/new units, expected/actual direction and decision effect, and mismatch diagnosis. No commit is made by this build.

## Named AI-use register

| Tool/model surface | Interaction date | Material contribution | Independent check / disposition | Effect |
|---|---|---|---|---|
| Codex; underlying model/version not exposed in runtime evidence | October19 2026 | Architecture, code, research retrieval, assumptions organization, tests, dashboard and draft documents | Automated independent arithmetic/identity/source checks executed; student review pending | Qualified provisional valuation; no human authorship claim |
| Codex historical checkout disclosure | September1 draft metadata | Filing organization and Edition A drafting disclosed in original checkout | Preserve disclosure; no receipt or AI-free claim | Baseline status accurately qualified |
| Codex historical labs | Lab-specific dates in preserved records | Lab modeling, checking and writing | Historical records retained; not recharacterized as unaided work | Reusable technical evidence only |

| AI output/claim | Disposition | Check | Result |
|---|---|---|---|
| Positive-only FCFE as final FCFF | Reject | Inspect value_equity and cash-flow definitions | New engine retains negatives and uses WACC |
| Initial PP&E mutation gate sufficient | Correct | Deliberate financed-asset omission | Added direct identity; tests pass |
| Broad reverse bracket always evaluable | Correct | Invalid terminal endpoint and repricing tests | Explicit valid diagnostic bracket; solved economics still qualified |
| Raw CFO D&A as comparable EBITDA addback | Modify | Microsoft Notes8/10 and cash-flow statement | Separate rounded depreciation + intangible amortization |
| Base point value as precise fair value | Qualify | Stub, bridge, missing assets and terminal challenge | Provisional recommendation only |

## Independent student evidence and limitations

Student source/definition checks, assessed AI-off work, actual recordings, corrected transcripts and external link access remain pending. Automated source token checks and AI reading do not certify that the student independently verified a filing. No partner conversation or attendance is invented. Full Brightspace brief/rubric remains unverified. Separate early-AI recovery clarification is pending; the user-supplied October19 announcement supports continuing with an accurately preserved original but is not labeled an explicit recovery waiver.

## Monitoring and escalation

Reassess only after supported signed-flow value and funding survive conservative reinvestment/operating cases, and the dated price offers an evidence-supported margin of safety. Stop treating the model as investable when funding is infeasible or accounting/convention checks fail. Preserve diagnostic failures rather than add unlimited financing.
