# Accounting and valuation conventions

## Selection and date

September10 2026 matches all peer closes and legacy dated WACC evidence. FY2025 audited statements and Q2 filed July30 were public. Original September1 thesis remains a separate historical artifact. This is a retrospective educational valuation prepared October19, not a backtest or claim that every forecast choice was locked September10. Remaining 2026 FCFF is 112/365 of full-year modeled FCFF; actual H1 and seasonality are not fully stub-reconciled. Latest available June30 bridge balances are used without pretending they are September10 observations. A precise point-in-time roll-forward remains a material improvement.

## Taxes and normalization

Reported opening balances remain unchanged. Economic operating NOPAT excludes nonoperating income and financing. No unsupported exceptional operating charge is added back. Unlevered tax is 22% of positive EBIT, inherited judgment; no automatic operating tax credit on losses. Deferred taxes, NOLs and investment-asset tax bases need further work. This is not a GAAP restatement or a claim that cash taxes equal the provision.

## Leases, investment and working capital

Operating leases remain rental expense and cash cost; no ROU addback and no operating-lease debt deduction. Finance leases/facility financing are financing claims, new assets are investment, and principal payments are excluded from FCFF. PP&E additions = cash net capex + capital AP change + finance lease additions + financed facility additions. Capital AP is investment working capital: its growth is a credit against accrued asset additions, producing cash investment plus noncash financed assets. Its liability is not separately deducted in the bridge. Neither lease additions nor debt issuance is free operating cash flow. Content/intangible replacement and amortization are assumed to offset within residual costs; no broader CFO D&A addback is made.

## Cash and investment assets

Deduct the legacy $25bn operating buffer from excess cash; reserve liquidation does not enter FCFF. Only reported cash/marketable securities are added separately. Private strategic investments and related deferred tax/commitment claims remain unvalued. Their zero supplemental adjustment means excluded, not worth zero. Published values are provisional and may materially understate equity value; no acquisition/investment funding model is invented. A $10bn supplement sensitivity is a unit effect, not an asset appraisal.

## Shares and compensation

10,786.313572m common shares July22 plus 134m Q2 incremental dilutive awards = proxy diluted valuation shares. This is not exact September10 treasury-stock dilution. Future SBC expense stays in operating costs, no addback/new issuance, under the historical cash-replacement judgment. Existing award overhang and future compensation expense are distinct, but the exact valuation treatment needs source review. EPS denominators remain annual diluted weighted-average shares in the P/E comparison.

## Terminal value

FY2031 operating margin and net invested-capital ratios stabilize; NOPAT grows at g and required net reinvestment is g times net PP&E less capital AP plus operating NWC and operating cash. Eligible D&A is added and matching replacement investment retained. The implied return on capital and sharp transition from heavy forecast investment are disclosed, not established facts. A separate carry-investment-intensity diagnostic exposes this model risk. No g/ROIC or capex assumption is tuned to a market target.

## Funding and recommendation

Report accounting validity separately from financing feasibility. Unfunded cases keep statements and diagnostic values but are excluded from investable spans. Retaining a watch/defer action is a qualified research judgment, not a mechanically justified fair-value claim. Change toward do not initiate if subsequent verified evidence establishes structural cash-return/funding failure; reconsider initiation only with complete supported value and a margin of safety.
