# FIN 43900 — AI in Finance (Fall 2026)

Course content home. All readings, handouts, prework, starters, and data
files live in this repository; videos are linked from the week pages.
**Everything graded — lab checkouts, projects, checkpoints, and all
deadlines — lives in Brightspace**, which is the authoritative source for
dates, points, and submissions. If this repo and Brightspace ever seem to
disagree about a requirement, Brightspace governs and the difference is a
bug worth reporting.

## Weeks

- [Start Here](lessons/week-00/)
- [Week 1 — Technology Readiness, DRIVER & Company Screening](lessons/week-01/) — projected slides: [Session 01](https://cinderzhang.github.io/FIN43900-Fall2026/lessons/week-01/slides-session-01.html) · [Session 02](https://cinderzhang.github.io/FIN43900-Fall2026/lessons/week-01/slides-session-02.html)
- [Week 2 — Valuation Foundations](lessons/week-02/) — projected slides: [Session 03](https://cinderzhang.github.io/FIN43900-Fall2026/lessons/week-02/slides-session-03.html) · [Session 04](https://cinderzhang.github.io/FIN43900-Fall2026/lessons/week-02/slides-session-04.html)
- [Week 3 — DCF & Sensitivity Analysis](lessons/week-03/) — projected slides: [Session 05](https://cinderzhang.github.io/FIN43900-Fall2026/lessons/week-03/slides-session-05.html) · [Session 06](https://cinderzhang.github.io/FIN43900-Fall2026/lessons/week-03/slides-session-06.html)
- [Week 4 — Comparable Companies & Deal Analysis](lessons/week-04/) — projected slides: [Session 07](https://cinderzhang.github.io/FIN43900-Fall2026/lessons/week-04/slides-session-07.html) · [Session 08](https://cinderzhang.github.io/FIN43900-Fall2026/lessons/week-04/slides-session-08.html)
- [Week 5 — Pro-Forma Financial Modeling I](lessons/week-05/) — video: [Pro-Forma Valuation with AI, Part 1 (27 min)](https://youtu.be/O4PeC2PqwRY) · slides: [Part 1](https://cinderzhang.github.io/FIN43900-Fall2026/lessons/week-05/pro-forma-abg-tutorial/video-1-build-the-base-case-slides.html) · [tutorial page](lessons/week-05/pro-forma-abg-tutorial/)
- [Week 6 — Pro-Forma Financial Modeling II](lessons/week-06/) — video: [Pro-Forma Valuation with AI, Part 2 (22 min)](https://youtu.be/zDBUpjaQzpo) · slides: [Part 2](https://cinderzhang.github.io/FIN43900-Fall2026/lessons/week-05/pro-forma-abg-tutorial/video-2-take-it-apart-and-present-slides.html) · [tutorial page](lessons/week-05/pro-forma-abg-tutorial/)
- [Week 7 — Project 1 Studio](lessons/week-07/)
- [Week 8 — Project 1 Due & Portfolio Construction Opens](lessons/week-08/)
- [Week 9 — Portfolio Construction & Optimization](lessons/week-09/) — projected slides: [Session 14](https://cinderzhang.github.io/FIN43900-Fall2026/lessons/week-09/slides-session-14.html) · [Session 15](https://cinderzhang.github.io/FIN43900-Fall2026/lessons/week-09/slides-session-15.html)
- [Week 10 — Alternative Data & Market Analysis](lessons/week-10/) — projected slides: [Session 16](https://cinderzhang.github.io/FIN43900-Fall2026/lessons/week-10/slides-session-16.html) · [Session 17](https://cinderzhang.github.io/FIN43900-Fall2026/lessons/week-10/slides-session-17.html)
- [Week 11 — Alternative Data & Market Analysis](lessons/week-11/) — projected slides: [Session 18](https://cinderzhang.github.io/FIN43900-Fall2026/lessons/week-11/slides-session-18.html) · [Session 19](https://cinderzhang.github.io/FIN43900-Fall2026/lessons/week-11/slides-session-19.html)
- [Week 12 — Project 2 Studio](lessons/week-12/)
- [Week 13 — Project 2 Due & Applied Decision Systems](lessons/week-13/) — projected slides: [Session 20](https://cinderzhang.github.io/FIN43900-Fall2026/lessons/week-13/slides-session-20.html) · [Session 25](https://cinderzhang.github.io/FIN43900-Fall2026/lessons/week-13/slides-session-25.html)
- [Week 14 — Applied Financial Decision Systems](lessons/week-14/) — projected slides: [Session 26](https://cinderzhang.github.io/FIN43900-Fall2026/lessons/week-14/slides-session-26.html)
- [Week 15 — Integrated Capstone Development](lessons/week-15/)
- [Week 16 — Capstone Submission & Consultation](lessons/week-16/)

## Projects

- [Project 1 — Corporate Finance Application](projects/project-1-corporate-finance-application.md)
- [Project 2 — Investment Management Application](projects/project-2-investment-management-application.md)

The `.html` slide files do not render inside the GitHub file browser —
use the projected-slides links above (arrow keys or click to advance).

## Weeks 13–14 — two complete tracks, your decision

Two complete two-week builds are published, and **you choose which one you dig
deep on**: **fixed income** ([lessons/week-13](lessons/week-13/) and
[lessons/week-14](lessons/week-14/) — class sessions walk this one) or
**robo-advisory** ([tracks/robo-advisory](tracks/robo-advisory/)) — projected slides: [Session 25](https://cinderzhang.github.io/FIN43900-Fall2026/tracks/robo-advisory/week-13/slides-session-25.html) · [Session 26](https://cinderzhang.github.io/FIN43900-Fall2026/tracks/robo-advisory/week-14/slides-session-26.html).
Either track counts, and either can seed your capstone. Both replicate real
open-source research with AI — the equipment, not the fish.